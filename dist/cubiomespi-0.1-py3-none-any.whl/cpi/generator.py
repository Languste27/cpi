class Generator:
    def __init__(self, mc: int, seed: int, dimension: int) -> None:

        self.version = mc
        self.seed = seed
        self.dimension = dimension